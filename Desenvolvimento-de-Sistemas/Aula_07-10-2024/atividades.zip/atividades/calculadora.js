function somar(numero1, numero2){
    return numero1+numero2;
}

function subtrair(numero1, numero2){
    return numero1-numero2;
}

module.exports = {somar,subtrair}