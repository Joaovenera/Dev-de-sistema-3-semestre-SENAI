//const calculadora = require('./calculadora.js');
const atividade1 = require('./atividade1.js');
const atividade2 = require('./atividade2.js');
const atividade3 = require('./atividade3.js');
const atividade4 = require('./atividade4.js');
const atividade5 = require('./atividade5.js');


console.log(atividade1.atividade1(10));
console.log(atividade2.atividade2(10));
console.log(atividade3.atividade3(10));
console.log(atividade4.atividade4("palindromo"));
console.log(atividade5.atividade5(10));


//console.log("Olá mundo!");
//console.log(calculadora.somar(10, 20));